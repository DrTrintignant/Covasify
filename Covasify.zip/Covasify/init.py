"""
Covasify - Spotify Integration Plugin for COVAS NEXT
Voice-controlled Spotify playback with binding system
"""